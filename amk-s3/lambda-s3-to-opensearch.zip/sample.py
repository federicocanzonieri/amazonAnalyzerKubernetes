import boto3
import re
import requests
from requests_aws4auth import AWS4Auth
import os
import json


headers = {
    # Already added when you pass json= but not when you pass data=
    'Content-Type': 'application/json',
}

json_data = {
    'properties': {
        '@timestamp': {
            'type': 'date',
            'format': 'epoch_second',
        },
        'rating': {
            'type': 'integer',
        },
        'title': {
            'type': 'keyword',
        },
        'body': {
            'type': 'keyword',
        },
        'date': {
            'type': 'date',
            'format': 'yyyy-MM-dd',
        },
        'name': {
            'type': 'keyword',
        },
        'verified_buy': {
            'type': 'keyword',
        },
        'helpful_vote': {
            'type': 'integer',
        },
        'country': {
            'type': 'keyword',
        },
        'sentiment': {
            'type': 'double',
        },
        'words': {
            'type': 'keyword',
        }
    },
}


# REGION = os.getenv('region_opensearch_cluster') # e.g. us-west-1
# SERVICE = 'es'

HOST = os.getenv('domain_url_opensearch') #the OpenSearch Service domain, including https://
INDEX = os.getenv('index_opensearch')
TYPE_DOC = '_doc'

AWS_ACCESS_KEY_ID=os.getenv("aws_access_key_id")
AWS_SECRET_ACCESS_KEY=os.getenv("aws_secret_access_key")

USERNAME_OP=os.getenv("username_opensearch")
PASSWORD_OP=os.getenv("password_opensearch")

# awsauth = AWS4Auth(username, password, REGION, SERVICE)

url = HOST + '/' + INDEX + '/' + TYPE_DOC
headers = { "Content-Type": "application/json" }

# print(REGION," ",SERVICE," ",HOST," ",INDEX," ",url)
response = requests.put( HOST + '/' + INDEX , headers=headers,  auth=(USERNAME_OP, PASSWORD_OP))
print(response)

response = requests.put( HOST + '/' + INDEX +"/_mappings", headers=headers,json=json_data ,auth=(USERNAME_OP, PASSWORD_OP))
print(response)


s3 = boto3.client('s3',aws_access_key_id=AWS_ACCESS_KEY_ID,aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
# Regular expressions used to parse some simple log lines
# Lambda execution starts here
def handler(event, context):
    # print("PROVA\n")
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        # print(bucket,key)
        # Get, read, and split the file into lines
        obj = s3.get_object(Bucket=bucket, Key=key)
        body=obj['Body'].read()
        # print(body)
        lines=body.splitlines()
        for line in lines:
            # print(line)
            r = requests.post(url, auth=(USERNAME_OP, PASSWORD_OP), json=json.loads(line) , headers=headers)
            # print(r)
            # print("\n")
            
            